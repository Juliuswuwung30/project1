//
//  ContentView.swift
//  MacProject1
//
//  Created by student on 26/04/24.
//
import SwiftUI


struct ContentView: View {
    var body: some View {
        LandmarkList()
            .frame(minWidth: 700, minHeight: 300)
    }
}


#Preview {
    ContentView()
        .environment(ModelData())
}
